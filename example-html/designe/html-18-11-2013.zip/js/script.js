$(document).ready(function() {
  $('a.fancybox').fancybox({
		'width':'80%',
		'minWidth':800,
		'padding': 0,
		'type': 'iframe',
		'autoScale': false,
		'hideOnContentClick': true,
  });	
  
});