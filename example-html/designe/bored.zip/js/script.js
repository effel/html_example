$(document).ready(function() {
  $('a.fancybox').fancybox({
		'width':'80%',
		'minWidth':1000,
		'padding': 0,
		'type': 'iframe',
		'autoScale': false,
		'hideOnContentClick': true,
  });	
  
});